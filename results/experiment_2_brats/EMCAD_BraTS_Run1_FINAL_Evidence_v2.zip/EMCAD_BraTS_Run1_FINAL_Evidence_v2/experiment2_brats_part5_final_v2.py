
import csv
import json
import logging
import math
import random
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms import InterpolationMode
from torchvision.transforms import functional as TF

from lib.networks import EMCADNet



# =============================================================================
# Author-equivalent binary loss and training utilities
# =============================================================================
# These definitions are copied behavior-for-behavior from the pinned EMCAD
# training utilities. Keeping them local avoids importing unrelated dataloaders
# and training entry points while preserving the same mathematics.

def structure_loss(pred, mask, w=1):
    weit = 1 + 5 * torch.abs(
        F.avg_pool2d(
            mask,
            kernel_size=31,
            stride=1,
            padding=15,
        ) - mask
    )

    wbce = F.binary_cross_entropy_with_logits(
        pred,
        mask,
        reduction="none",
    )

    wbce = (
        (weit * wbce).sum(dim=(2, 3))
        / weit.sum(dim=(2, 3))
    )

    pred = torch.sigmoid(pred)

    inter = (
        (pred * mask) * weit
    ).sum(dim=(2, 3))

    union = (
        (pred + mask) * weit
    ).sum(dim=(2, 3))

    wiou = 1 - (
        (inter + 1)
        / (union - inter + 1)
    )

    return (
        w * (wbce + wiou)
    ).mean()


def clip_gradient(optimizer, grad_clip):
    for group in optimizer.param_groups:
        for param in group["params"]:
            if param.grad is not None:
                param.grad.data.clamp_(
                    -grad_clip,
                    grad_clip,
                )


def adjust_lr(
    optimizer,
    init_lr,
    epoch,
    decay_rate=0.1,
    decay_epoch=30,
):
    # This matches the author's utility. For our configured decay_epoch=300
    # and epochs <=200 the multiplier is 1, so it is neutral.
    decay = decay_rate ** (
        epoch // decay_epoch
    )

    for param_group in optimizer.param_groups:
        param_group["lr"] *= decay


# =============================================================================
# Configuration
# =============================================================================

WORK = Path("/kaggle/working")
DATA_ROOT = WORK / "EMCAD_BraTS_Part1_Output"
OUTPUT_ROOT = WORK / "EMCAD_BraTS_Run1_Part5"

SEED = 2026

START_EPOCH = 151
END_EPOCH = 200
TOTAL_EPOCHS = 200

IMG_SIZE = 352
BATCH_SIZE = 8
VAL_BATCH_SIZE = 16

LR = 5e-4
WEIGHT_DECAY = 1e-4
ETA_MIN = 1e-6

CLIP = 0.5
DECAY_RATE = 0.1
DECAY_EPOCH = 300

SIZE_RATES = [0.75, 1.0, 1.25]
THRESHOLD = 0.5

KERNEL_SIZES = [1, 3, 5]
EXPANSION_FACTOR = 2
LGAG_KS = 3
ACTIVATION = "relu6"
ENCODER = "pvt_v2_b2"
PRETRAINED_DIR = "./pretrained_pth/pvt/"

AUTHOR_COMMIT = "26c9c31f731f749b62c5fe83f44376dac75f3aa8"

IMAGENET_MEAN = torch.tensor(
    [0.485, 0.456, 0.406]
).view(3, 1, 1)

IMAGENET_STD = torch.tensor(
    [0.229, 0.224, 0.225]
).view(3, 1, 1)

OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)


# =============================================================================
# Reproducibility
# =============================================================================

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


# =============================================================================
# Prepared-data preflight
# =============================================================================

def load_preparation_metadata():
    split = json.loads(
        (DATA_ROOT / "patient_split.json").read_text()
    )

    metadata = json.loads(
        (DATA_ROOT / "preparation_metadata.json").read_text()
    )

    assert len(split["train"]) == 388
    assert len(split["val"]) == 48
    assert len(split["test"]) == 48

    assert not (set(split["train"]) & set(split["val"]))
    assert not (set(split["train"]) & set(split["test"]))
    assert not (set(split["val"]) & set(split["test"]))

    assert metadata["target"] == "Whole Tumour (WT): label > 0"

    print("Patient split: 388 / 48 / 48")
    print("Target:", metadata["target"])
    print(
        "Input modalities:",
        metadata["selected_input_modalities"],
    )
    print("Patient leakage check: PASS")

    return split, metadata


# =============================================================================
# PyTorch datasets
# =============================================================================

def preprocess(image, mask, training):
    image = image.float()
    mask = mask.float()

    if training:
        if random.random() < 0.5:
            angle = random.uniform(-90.0, 90.0)

            image = TF.rotate(
                image,
                angle,
                interpolation=InterpolationMode.BILINEAR,
            )

            mask = TF.rotate(
                mask,
                angle,
                interpolation=InterpolationMode.NEAREST,
            )

        if random.random() < 0.5:
            image = TF.hflip(image)
            mask = TF.hflip(mask)

        if random.random() < 0.5:
            image = TF.vflip(image)
            mask = TF.vflip(mask)

    image = TF.resize(
        image,
        [IMG_SIZE, IMG_SIZE],
        interpolation=InterpolationMode.BILINEAR,
    )

    mask = TF.resize(
        mask,
        [IMG_SIZE, IMG_SIZE],
        interpolation=InterpolationMode.NEAREST,
    )

    image = (
        image - IMAGENET_MEAN
    ) / IMAGENET_STD

    mask = (mask > 0.5).float()

    return image, mask


class TrainPatientDataset(Dataset):
    """
    One training item = one patient.

    Each epoch draws one slice at random from that patient's prepared
    2D slice bank. This keeps patient representation balanced while
    presenting different tumour/non-tumour slices across epochs.
    """

    def __init__(self):
        paths = sorted(
            (DATA_ROOT / "slice_cache" / "train").glob("*.pt")
        )

        if len(paths) != 388:
            raise RuntimeError(
                f"Expected 388 train patient caches, found {len(paths)}."
            )

        self.cases = [
            torch.load(path, map_location="cpu")
            for path in paths
        ]

    def __len__(self):
        return len(self.cases)

    def __getitem__(self, index):
        case = self.cases[index]

        sample_index = random.randrange(
            case["images"].shape[0]
        )

        image = case["images"][sample_index]
        mask = case["masks"][sample_index]

        return preprocess(
            image,
            mask,
            training=True,
        )


class ValidationSliceDataset(Dataset):
    """
    Validation is deterministic: every cached validation slice is used.
    """

    def __init__(self):
        paths = sorted(
            (DATA_ROOT / "slice_cache" / "val").glob("*.pt")
        )

        if len(paths) != 48:
            raise RuntimeError(
                f"Expected 48 validation patient caches, found {len(paths)}."
            )

        self.samples = []

        for path in paths:
            case = torch.load(
                path,
                map_location="cpu",
            )

            for index in range(
                case["images"].shape[0]
            ):
                self.samples.append(
                    (
                        case["patient_id"],
                        int(
                            case["slice_indices"][index].item()
                        ),
                        case["images"][index],
                        case["masks"][index],
                    )
                )

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        patient_id, slice_index, image, mask = (
            self.samples[index]
        )

        image, mask = preprocess(
            image,
            mask,
            training=False,
        )

        return (
            image,
            mask,
            patient_id,
            slice_index,
        )


def build_loaders():
    train_dataset = TrainPatientDataset()
    val_dataset = ValidationSliceDataset()

    shuffle_generator = torch.Generator()
    shuffle_generator.manual_seed(SEED)

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
        generator=shuffle_generator,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=VAL_BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=True,
    )

    print("Train patients per epoch:", len(train_dataset))
    print("Train batches per epoch:", len(train_loader))
    print("Validation slices:", len(val_dataset))
    print("Validation batches:", len(val_loader))

    return train_loader, val_loader, shuffle_generator


# =============================================================================
# Model and author-style loss
# =============================================================================

def build_model():
    # Architecture is identical to the previous stages.
    # pretrain=False only prevents an unnecessary attempt to read the original
    # ImageNet initialization file. The complete epoch-150 model state is
    # loaded with strict=True before training resumes.
    model = EMCADNet(
        num_classes=1,
        kernel_sizes=KERNEL_SIZES,
        expansion_factor=EXPANSION_FACTOR,
        dw_parallel=True,
        add=True,
        lgag_ks=LGAG_KS,
        activation=ACTIVATION,
        encoder=ENCODER,
        pretrain=False,
        pretrained_dir=PRETRAINED_DIR,
    )

    return model


def emcad_loss(outputs, masks):
    if not isinstance(outputs, list):
        outputs = [outputs]

    if len(outputs) != 4:
        raise RuntimeError(
            f"Expected four EMCAD outputs, got {len(outputs)}."
        )

    loss_p1 = structure_loss(outputs[0], masks)
    loss_p2 = structure_loss(outputs[1], masks)
    loss_p3 = structure_loss(outputs[2], masks)
    loss_p4 = structure_loss(outputs[3], masks)

    loss_p1234 = structure_loss(
        outputs[0]
        + outputs[1]
        + outputs[2]
        + outputs[3],
        masks,
    )

    return (
        loss_p1
        + loss_p2
        + loss_p3
        + loss_p4
        + loss_p1234
    )


# =============================================================================
# Metrics
# =============================================================================

def confusion_counts(prediction, target):
    prediction = prediction.bool()
    target = target.bool()

    tp = torch.logical_and(
        prediction,
        target,
    ).sum().item()

    tn = torch.logical_and(
        ~prediction,
        ~target,
    ).sum().item()

    fp = torch.logical_and(
        prediction,
        ~target,
    ).sum().item()

    fn = torch.logical_and(
        ~prediction,
        target,
    ).sum().item()

    return tp, tn, fp, fn


def metrics_from_counts(tp, tn, fp, fn):
    eps = 1e-6

    return {
        "dice": (
            2 * tp + eps
        ) / (
            2 * tp + fp + fn + eps
        ),
        "iou": (
            tp + eps
        ) / (
            tp + fp + fn + eps
        ),
        "sensitivity": (
            tp + eps
        ) / (
            tp + fn + eps
        ),
        "specificity": (
            tn + eps
        ) / (
            tn + fp + eps
        ),
        "precision": (
            tp + eps
        ) / (
            tp + fp + eps
        ),
        "accuracy": (
            tp + tn + eps
        ) / (
            tp + tn + fp + fn + eps
        ),
    }


def validate(model, loader, device):
    model.eval()

    tp = tn = fp = fn = 0

    with torch.no_grad():
        for images, masks, _, _ in loader:
            images = images.to(
                device,
                non_blocking=True,
            )

            masks = masks.to(
                device,
                non_blocking=True,
            ).float()

            outputs = model(images)

            if not isinstance(outputs, list):
                outputs = [outputs]

            logits = outputs[-1]

            predictions = (
                torch.sigmoid(logits)
                >= THRESHOLD
            )

            targets = masks >= 0.5

            counts = confusion_counts(
                predictions,
                targets,
            )

            tp += counts[0]
            tn += counts[1]
            fp += counts[2]
            fn += counts[3]

    return metrics_from_counts(
        tp,
        tn,
        fp,
        fn,
    )


# =============================================================================
# Training
# =============================================================================

def train_one_epoch(
    model,
    loader,
    optimizer,
    epoch,
    device,
):
    model.train()

    running_loss = 0.0
    samples = 0

    for step, (images, masks) in enumerate(
        loader,
        start=1,
    ):
        images = images.to(
            device,
            non_blocking=True,
        )

        masks = masks.to(
            device,
            non_blocking=True,
        ).float()

        for rate in SIZE_RATES:
            optimizer.zero_grad()

            if rate != 1.0:
                train_size = int(
                    round(
                        IMG_SIZE * rate / 32
                    ) * 32
                )

                current_images = F.interpolate(
                    images,
                    size=(train_size, train_size),
                    mode="bilinear",
                    align_corners=True,
                )

                current_masks = F.interpolate(
                    masks,
                    size=(train_size, train_size),
                    mode="nearest",
                )

            else:
                current_images = images
                current_masks = masks

            outputs = model(current_images)

            loss = emcad_loss(
                outputs,
                current_masks,
            )

            loss.backward()

            clip_gradient(
                optimizer,
                CLIP,
            )

            optimizer.step()

            if rate == 1.0:
                batch_size = images.size(0)

                running_loss += (
                    loss.item() * batch_size
                )

                samples += batch_size

        if (
            step % 25 == 0
            or step == len(loader)
        ):
            print(
                f"{datetime.now()} "
                f"Epoch [{epoch:03d}/{TOTAL_EPOCHS:03d}], "
                f"Step [{step:04d}/{len(loader):04d}], "
                f"LR: {optimizer.param_groups[0]['lr']:.6f}, "
                f"Loss: {running_loss / samples:.4f}"
            )

    return running_loss / samples


def save_history(path, history):
    if not history:
        return

    with path.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=history[0].keys(),
        )

        writer.writeheader()
        writer.writerows(history)


def save_resume_state(
    path,
    epoch,
    model,
    optimizer,
    scheduler,
    shuffle_generator,
    best_val_dice,
    best_epoch,
    history,
):
    state = {
        "stage": "BraTS Run 1 Part 5",
        "epoch": epoch,
        "total_epochs": TOTAL_EPOCHS,
        "seed": SEED,
        "author_commit": AUTHOR_COMMIT,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict(),
        "best_val_dice": best_val_dice,
        "best_epoch": best_epoch,
        "history": history,
        "python_random_state": random.getstate(),
        "numpy_random_state": np.random.get_state(),
        "torch_rng_state": torch.get_rng_state(),
        "cuda_rng_state_all": torch.cuda.get_rng_state_all(),
        "shuffle_generator_state": shuffle_generator.get_state(),
        "config": {
            "img_size": IMG_SIZE,
            "batch_size": BATCH_SIZE,
            "lr": LR,
            "weight_decay": WEIGHT_DECAY,
            "eta_min": ETA_MIN,
            "clip": CLIP,
            "size_rates": SIZE_RATES,
            "kernel_sizes": KERNEL_SIZES,
            "expansion_factor": EXPANSION_FACTOR,
            "lgag_ks": LGAG_KS,
            "activation": ACTIVATION,
            "encoder": ENCODER,
        },
    }

    torch.save(
        state,
        path,
    )


# =============================================================================
# Main
# =============================================================================



# =============================================================================
# Exact continuation utilities
# =============================================================================

def restore_rng_state(checkpoint, shuffle_generator):
    random.setstate(checkpoint["python_random_state"])
    np.random.set_state(checkpoint["numpy_random_state"])

    torch.set_rng_state(
        checkpoint["torch_rng_state"].cpu()
    )

    cuda_states = [
        state.cpu()
        for state in checkpoint["cuda_rng_state_all"]
    ]

    if not cuda_states:
        raise RuntimeError(
            "The resume checkpoint does not contain a CUDA RNG state."
        )

    # Training uses cuda:0 only. Restoring that exact saved generator state
    # keeps the run continuous even if Kaggle exposes a different GPU count.
    torch.cuda.set_rng_state(
        cuda_states[0],
        device=0,
    )

    shuffle_generator.set_state(
        checkpoint["shuffle_generator_state"].cpu()
    )


def move_optimizer_state_to_device(optimizer, device):
    for state in optimizer.state.values():
        for key, value in state.items():
            if torch.is_tensor(value):
                state[key] = value.to(device)


def verify_resume_checkpoint(checkpoint):
    if checkpoint["epoch"] != 150:
        raise RuntimeError(
            "Expected the Part 4 resume checkpoint at epoch 150, "
            f"found {checkpoint['epoch']}."
        )

    if checkpoint["total_epochs"] != TOTAL_EPOCHS:
        raise RuntimeError("Total epoch count changed.")

    if checkpoint["seed"] != SEED:
        raise RuntimeError("Run seed changed.")

    if checkpoint["author_commit"] != AUTHOR_COMMIT:
        raise RuntimeError("Author commit changed.")

    expected_config = {
        "img_size": IMG_SIZE,
        "batch_size": BATCH_SIZE,
        "lr": LR,
        "weight_decay": WEIGHT_DECAY,
        "eta_min": ETA_MIN,
        "clip": CLIP,
        "size_rates": SIZE_RATES,
        "kernel_sizes": KERNEL_SIZES,
        "expansion_factor": EXPANSION_FACTOR,
        "lgag_ks": LGAG_KS,
        "activation": ACTIVATION,
        "encoder": ENCODER,
    }

    if checkpoint["config"] != expected_config:
        raise RuntimeError(
            "Training configuration differs from the previous stage."
        )

    history = checkpoint["history"]

    if len(history) != 150:
        raise RuntimeError(
            f"Expected 150 cumulative history rows, found {len(history)}."
        )

    if int(history[-1]["epoch"]) != 150:
        raise RuntimeError(
            "Training history does not end at epoch 150."
        )

    print("Resume checkpoint verification: PASS")
    print("Previous epoch:", checkpoint["epoch"])
    print("Previous best epoch:", checkpoint["best_epoch"])
    print(
        "Previous best validation Dice:",
        f"{checkpoint['best_val_dice']:.4f}",
    )


# =============================================================================
# Full-volume BraTS test utilities
# =============================================================================

def case_id(path):
    name = Path(path).name

    if name.endswith(".nii.gz"):
        return name[:-7]

    return Path(name).stem


def write_rows_csv(path, rows):
    if not rows:
        return

    with path.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=rows[0].keys(),
        )

        writer.writeheader()
        writer.writerows(rows)


def load_test_case(image_path, label_path):
    import nibabel as nib

    image_nii = nib.load(str(image_path))
    label_nii = nib.load(str(label_path))

    image_np = np.asarray(
        image_nii.dataobj,
        dtype=np.float32,
    )

    label_np = np.asarray(
        label_nii.dataobj,
        dtype=np.int16,
    )

    if image_np.ndim != 4:
        raise RuntimeError(
            f"Expected a 4D MRI volume, got {image_np.shape}: "
            f"{image_path}"
        )

    modality_axes = [
        axis
        for axis, size in enumerate(image_np.shape)
        if size == 4
    ]

    if len(modality_axes) != 1:
        raise RuntimeError(
            f"Cannot uniquely identify the MRI modality axis: "
            f"{image_path} -> {image_np.shape}"
        )

    image_np = np.moveaxis(
        image_np,
        modality_axes[0],
        0,
    )

    if image_np.shape[1:] != label_np.shape:
        raise RuntimeError(
            f"Image/label spatial mismatch for {image_path.name}: "
            f"{image_np.shape} vs {label_np.shape}"
        )

    # dataset.json established the channel mapping:
    # 0 = FLAIR, 2 = T1-Gd, 3 = T2.
    selected = torch.from_numpy(
        image_np[[0, 2, 3]]
    ).float()

    label = torch.from_numpy(
        label_np
    )

    whole_tumour = (
        label > 0
    ).to(torch.uint8)

    brain = (
        selected.abs().sum(dim=0) > 0
    )

    normalized = torch.zeros_like(selected)

    for channel in range(selected.shape[0]):
        values = selected[channel][brain]

        if values.numel() == 0:
            raise RuntimeError(
                f"Empty brain region: {image_path.name}"
            )

        mu = values.mean()
        sigma = values.std()

        if sigma <= 0:
            raise RuntimeError(
                f"Zero intensity variance: {image_path.name}, "
                f"channel={channel}"
            )

        zscore = (
            selected[channel] - mu
        ) / sigma

        zscore = zscore.clamp(
            -5.0,
            5.0,
        )

        normalized[channel][brain] = (
            zscore[brain] + 5.0
        ) / 10.0

    return (
        normalized,
        whole_tumour,
        brain,
        image_nii.affine,
        image_nii.header.copy(),
    )


def preprocess_test_batch(batch, device):
    batch = batch.to(
        device,
        non_blocking=True,
    ).float()

    batch = F.interpolate(
        batch,
        size=(IMG_SIZE, IMG_SIZE),
        mode="bilinear",
        align_corners=False,
    )

    mean_tensor = IMAGENET_MEAN.to(device)
    std_tensor = IMAGENET_STD.to(device)

    batch = (
        batch - mean_tensor
    ) / std_tensor

    return batch


def hd95_surface_distance(prediction, target, spacing):
    """
    Symmetric 95th-percentile Hausdorff distance in physical units.

    Returns NaN when either binary mask is empty. Empty-prediction cases are
    reported explicitly rather than being hidden behind an arbitrary penalty.
    """
    from scipy.ndimage import (
        binary_erosion,
        distance_transform_edt,
    )

    prediction = prediction.astype(bool)
    target = target.astype(bool)

    if not prediction.any() or not target.any():
        return float("nan")

    pred_surface = np.logical_xor(
        prediction,
        binary_erosion(
            prediction,
            structure=np.ones((3, 3, 3), dtype=bool),
            border_value=0,
        ),
    )

    target_surface = np.logical_xor(
        target,
        binary_erosion(
            target,
            structure=np.ones((3, 3, 3), dtype=bool),
            border_value=0,
        ),
    )

    if not pred_surface.any() or not target_surface.any():
        return float("nan")

    distance_to_target = distance_transform_edt(
        ~target_surface,
        sampling=spacing,
    )

    distance_to_prediction = distance_transform_edt(
        ~pred_surface,
        sampling=spacing,
    )

    distances = np.concatenate(
        [
            distance_to_target[pred_surface],
            distance_to_prediction[target_surface],
        ]
    )

    return float(
        np.percentile(
            distances,
            95,
        )
    )


def evaluate_full_test_case(
    model,
    image_path,
    label_path,
    device,
    prediction_dir,
    qualitative_dir,
    save_qualitative=False,
):
    import nibabel as nib
    from PIL import Image

    (
        image,
        target,
        brain,
        affine,
        header,
    ) = load_test_case(
        image_path,
        label_path,
    )

    height, width, depth = target.shape

    prediction = torch.zeros(
        (height, width, depth),
        dtype=torch.uint8,
    )

    # Processing only non-empty brain slices is equivalent to processing
    # the complete volume because non-brain slices are explicitly kept at 0.
    z_indices = [
        z
        for z in range(depth)
        if brain[:, :, z].any().item()
    ]

    test_batch_size = 8

    model.eval()

    with torch.no_grad():
        for start in range(
            0,
            len(z_indices),
            test_batch_size,
        ):
            current_z = z_indices[
                start:start + test_batch_size
            ]

            batch = torch.stack(
                [
                    image[:, :, :, z]
                    for z in current_z
                ],
                dim=0,
            )

            batch = preprocess_test_batch(
                batch,
                device,
            )

            outputs = model(batch)

            if not isinstance(outputs, list):
                outputs = [outputs]

            if len(outputs) != 4:
                raise RuntimeError(
                    f"Expected four EMCAD outputs, got {len(outputs)}."
                )

            # EMCAD paper: p4 is the final segmentation map.
            logits = outputs[-1]

            logits = F.interpolate(
                logits,
                size=(height, width),
                mode="bilinear",
                align_corners=False,
            )

            predicted = (
                torch.sigmoid(logits)
                >= THRESHOLD
            ).to(
                torch.uint8
            ).cpu()

            for local_index, z in enumerate(
                current_z
            ):
                prediction[:, :, z] = (
                    predicted[local_index, 0]
                )

    target_bool = target.bool()
    prediction_bool = prediction.bool()

    tp, tn, fp, fn = confusion_counts(
        prediction_bool,
        target_bool,
    )

    metrics = metrics_from_counts(
        tp,
        tn,
        fp,
        fn,
    )

    spacing = tuple(
        float(value)
        for value in header.get_zooms()[:3]
    )

    metrics["hd95"] = hd95_surface_distance(
        prediction_bool.numpy(),
        target_bool.numpy(),
        spacing=spacing,
    )

    metrics["tp"] = int(tp)
    metrics["tn"] = int(tn)
    metrics["fp"] = int(fp)
    metrics["fn"] = int(fn)

    patient = case_id(label_path)

    prediction_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    pred_nii = nib.Nifti1Image(
        prediction.numpy().astype(np.uint8),
        affine,
        header=header,
    )

    prediction_path = (
        prediction_dir
        / f"{patient}_WT_pred.nii.gz"
    )

    nib.save(
        pred_nii,
        str(prediction_path),
    )

    if save_qualitative:
        qualitative_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        tumour_area = target.sum(
            dim=(0, 1)
        )

        z = int(
            tumour_area.argmax().item()
        )

        flair = image[0, :, :, z].clone()
        gt = target[:, :, z].float()
        pred = prediction[:, :, z].float()

        def to_uint8(tensor):
            tensor = tensor.float()
            low = tensor.min()
            high = tensor.max()

            if high > low:
                tensor = (
                    tensor - low
                ) / (
                    high - low
                )

            return (
                tensor.clamp(0, 1) * 255
            ).to(
                torch.uint8
            ).numpy()

        Image.fromarray(
            to_uint8(flair)
        ).save(
            qualitative_dir
            / f"{patient}_z{z:03d}_FLAIR.png"
        )

        Image.fromarray(
            to_uint8(gt)
        ).save(
            qualitative_dir
            / f"{patient}_z{z:03d}_GT_WT.png"
        )

        Image.fromarray(
            to_uint8(pred)
        ).save(
            qualitative_dir
            / f"{patient}_z{z:03d}_PRED_WT.png"
        )

    return metrics


def evaluate_full_test_set(model, split, device):
    image_root = (
        DATA_ROOT
        / "test_volumes"
        / "images"
    )

    label_root = (
        DATA_ROOT
        / "test_volumes"
        / "labels"
    )

    images = {
        case_id(path): path
        for path in image_root.glob("*.nii.gz")
    }

    labels = {
        case_id(path): path
        for path in label_root.glob("*.nii.gz")
    }

    test_patients = split["test"]

    if set(test_patients) != set(images):
        raise RuntimeError(
            "Staged test image IDs do not match the fixed patient split."
        )

    if set(test_patients) != set(labels):
        raise RuntimeError(
            "Staged test label IDs do not match the fixed patient split."
        )

    prediction_dir = (
        OUTPUT_ROOT
        / "test_predictions"
    )

    qualitative_dir = (
        OUTPUT_ROOT
        / "qualitative_examples"
    )

    rows = []

    global_tp = 0
    global_tn = 0
    global_fp = 0
    global_fn = 0

    for index, patient in enumerate(
        test_patients,
        start=1,
    ):
        metrics = evaluate_full_test_case(
            model=model,
            image_path=images[patient],
            label_path=labels[patient],
            device=device,
            prediction_dir=prediction_dir,
            qualitative_dir=qualitative_dir,
            save_qualitative=(index <= 6),
        )

        row = {
            "patient_id": patient,
            "dice": metrics["dice"],
            "iou": metrics["iou"],
            "sensitivity": metrics["sensitivity"],
            "specificity": metrics["specificity"],
            "precision": metrics["precision"],
            "accuracy": metrics["accuracy"],
            "hd95": metrics["hd95"],
            "tp": metrics["tp"],
            "tn": metrics["tn"],
            "fp": metrics["fp"],
            "fn": metrics["fn"],
        }

        rows.append(row)

        global_tp += metrics["tp"]
        global_tn += metrics["tn"]
        global_fp += metrics["fp"]
        global_fn += metrics["fn"]

        hd95_text = (
            f"{metrics['hd95']:.3f}"
            if math.isfinite(metrics["hd95"])
            else "NaN"
        )

        print(
            f"Test {index:02d}/{len(test_patients):02d} "
            f"{patient}: "
            f"Dice={metrics['dice']:.4f}, "
            f"IoU={metrics['iou']:.4f}, "
            f"HD95={hd95_text}"
        )

    write_rows_csv(
        OUTPUT_ROOT
        / "test_patient_metrics.csv",
        rows,
    )

    metric_names = [
        "dice",
        "iou",
        "sensitivity",
        "specificity",
        "precision",
        "accuracy",
        "hd95",
    ]

    macro = {}

    for name in metric_names:
        values = [
            float(row[name])
            for row in rows
            if math.isfinite(
                float(row[name])
            )
        ]

        macro[name] = {
            "mean": float(
                np.mean(values)
            ),
            "std": float(
                np.std(
                    values,
                    ddof=1,
                )
            )
            if len(values) > 1
            else 0.0,
            "n": len(values),
        }

    global_metrics = metrics_from_counts(
        global_tp,
        global_tn,
        global_fp,
        global_fn,
    )

    empty_predictions = sum(
        1
        for row in rows
        if int(row["tp"]) + int(row["fp"]) == 0
    )

    summary = {
        "patients": len(rows),
        "macro_patient_metrics": macro,
        "global_voxel_metrics": global_metrics,
        "global_counts": {
            "tp": int(global_tp),
            "tn": int(global_tn),
            "fp": int(global_fp),
            "fn": int(global_fn),
        },
        "hd95_valid_patients": macro["hd95"]["n"],
        "empty_prediction_patients": empty_predictions,
        "threshold": THRESHOLD,
        "test_selection_policy": (
            "held-out patient split; evaluated once after 200 epochs "
            "using the best validation checkpoint"
        ),
    }

    (
        OUTPUT_ROOT
        / "test_summary.json"
    ).write_text(
        json.dumps(
            summary,
            indent=2,
        )
    )

    return summary


# =============================================================================
# Final Run 1
# =============================================================================

def main():
    set_seed(SEED)

    split, preparation_metadata = (
        load_preparation_metadata()
    )

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    if device.type != "cuda":
        raise RuntimeError(
            "GPU is required for training."
        )

    print("Device:", device)
    print("GPU:", torch.cuda.get_device_name(0))
    print("PyTorch:", torch.__version__)

    train_loader, val_loader, shuffle_generator = (
        build_loaders()
    )

    # Deterministic prepared-cache preflight.
    images, masks = next(
        iter(
            DataLoader(
                train_loader.dataset,
                batch_size=2,
                shuffle=False,
                num_workers=0,
            )
        )
    )

    assert images.shape == (
        2,
        3,
        IMG_SIZE,
        IMG_SIZE,
    )

    assert masks.shape == (
        2,
        1,
        IMG_SIZE,
        IMG_SIZE,
    )

    assert masks.max().item() == 1.0

    print("Prepared-cache preflight: PASS")

    model = build_model().to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        LR,
        weight_decay=WEIGHT_DECAY,
    )

    scheduler = CosineAnnealingLR(
        optimizer,
        T_max=TOTAL_EPOCHS,
        eta_min=ETA_MIN,
    )

    prior_root = (
        WORK
        / "EMCAD_BraTS_Run1_Part4_State"
    )

    resume_path = (
        prior_root
        / "resume_epoch150.pth"
    )

    prior_best_path = (
        prior_root
        / "best_through_epoch150.pth"
    )

    if not resume_path.is_file():
        raise FileNotFoundError(
            resume_path
        )

    if not prior_best_path.is_file():
        raise FileNotFoundError(
            prior_best_path
        )

    checkpoint = torch.load(
        resume_path,
        map_location=device,
    )

    verify_resume_checkpoint(
        checkpoint
    )

    model.load_state_dict(
        checkpoint["model_state_dict"],
        strict=True,
    )

    optimizer.load_state_dict(
        checkpoint["optimizer_state_dict"]
    )

    move_optimizer_state_to_device(
        optimizer,
        device,
    )

    scheduler.load_state_dict(
        checkpoint["scheduler_state_dict"]
    )

    best_val_dice = float(
        checkpoint["best_val_dice"]
    )

    best_epoch = int(
        checkpoint["best_epoch"]
    )

    history = list(
        checkpoint["history"]
    )

    best_path = (
        OUTPUT_ROOT
        / "best_through_epoch200.pth"
    )

    import shutil

    shutil.copy2(
        prior_best_path,
        best_path,
    )

    # Restore the exact stochastic state only after all setup work.
    restore_rng_state(
        checkpoint,
        shuffle_generator,
    )

    print(
        "Resuming the same Run 1 at epoch:",
        START_EPOCH,
    )

    print(
        "Scheduler last_epoch:",
        scheduler.last_epoch,
    )

    print(
        "Optimizer LR at resume:",
        f"{optimizer.param_groups[0]['lr']:.6f}",
    )

    log_path = (
        OUTPUT_ROOT
        / "training_part5.log"
    )

    logging.basicConfig(
        filename=log_path,
        level=logging.INFO,
        format="[%(asctime)s] %(message)s",
        force=True,
    )

    stage_start = time.time()

    for epoch in range(
        START_EPOCH,
        END_EPOCH + 1,
    ):
        epoch_start = time.time()

        adjust_lr(
            optimizer,
            LR,
            epoch,
            DECAY_RATE,
            DECAY_EPOCH,
        )

        train_loss = train_one_epoch(
            model=model,
            loader=train_loader,
            optimizer=optimizer,
            epoch=epoch,
            device=device,
        )

        val_metrics = validate(
            model,
            val_loader,
            device,
        )

        epoch_time = (
            time.time() - epoch_start
        )

        row = {
            "epoch": epoch,
            "lr": optimizer.param_groups[0]["lr"],
            "train_loss": train_loss,
            "val_dice": val_metrics["dice"],
            "val_iou": val_metrics["iou"],
            "val_sensitivity": val_metrics["sensitivity"],
            "val_specificity": val_metrics["specificity"],
            "val_precision": val_metrics["precision"],
            "val_accuracy": val_metrics["accuracy"],
            "epoch_time_seconds": epoch_time,
        }

        history.append(row)

        message = (
            f"Epoch: {epoch:03d}, Dataset: val, "
            f"Dice: {val_metrics['dice']:.4f}, "
            f"IoU: {val_metrics['iou']:.4f}, "
            f"Time: {epoch_time:.1f}s"
        )

        print(message)
        logging.info(message)

        if (
            val_metrics["dice"]
            > best_val_dice
        ):
            previous = best_val_dice

            best_val_dice = (
                val_metrics["dice"]
            )

            best_epoch = epoch

            torch.save(
                model.state_dict(),
                best_path,
            )

            best_message = (
                "### Best Model Saved "
                f"(Dice improved from "
                f"{previous:.4f} to "
                f"{best_val_dice:.4f}) ###"
            )

            print(best_message)
            logging.info(best_message)

        scheduler.step()

        save_history(
            OUTPUT_ROOT
            / "history_through_epoch200.csv",
            history,
        )

        save_resume_state(
            OUTPUT_ROOT
            / "resume_latest.pth",
            epoch=epoch,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            shuffle_generator=shuffle_generator,
            best_val_dice=best_val_dice,
            best_epoch=best_epoch,
            history=history,
        )

    training_elapsed = (
        time.time() - stage_start
    )

    final_resume = (
        OUTPUT_ROOT
        / "resume_epoch200.pth"
    )

    save_resume_state(
        final_resume,
        epoch=END_EPOCH,
        model=model,
        optimizer=optimizer,
        scheduler=scheduler,
        shuffle_generator=shuffle_generator,
        best_val_dice=best_val_dice,
        best_epoch=best_epoch,
        history=history,
    )

    if len(history) != 200:
        raise RuntimeError(
            f"Expected 200 cumulative history rows, "
            f"found {len(history)}."
        )

    print()
    print("=" * 72)
    print("TRAINING COMPLETE — 200/200 EPOCHS")
    print("=" * 72)
    print("Best validation epoch:", best_epoch)
    print(
        "Best validation Dice:",
        f"{best_val_dice:.4f}",
    )
    print(
        "Part 5 training time:",
        f"{training_elapsed / 3600:.2f} hours",
    )
    print("=" * 72)

    # -----------------------------------------------------------------
    # Test is touched only now, after all 200 epochs and model selection.
    # -----------------------------------------------------------------

    print()
    print(
        "Loading the best validation checkpoint for the "
        "single final held-out test evaluation..."
    )

    model.load_state_dict(
        torch.load(
            best_path,
            map_location=device,
        ),
        strict=True,
    )

    test_start = time.time()

    test_summary = (
        evaluate_full_test_set(
            model=model,
            split=split,
            device=device,
        )
    )

    test_elapsed = (
        time.time() - test_start
    )

    final_summary = {
        "experiment": (
            "EMCAD Experiment 2 - BraTS Neuroimaging "
            "Domain Generalization"
        ),
        "run": 1,
        "seed": SEED,
        "epochs": TOTAL_EPOCHS,
        "best_validation_epoch": best_epoch,
        "best_validation_dice": best_val_dice,
        "test": test_summary,
        "part5_training_seconds": training_elapsed,
        "final_test_seconds": test_elapsed,
        "test_evaluated_once": True,
        "early_stopping": False,
        "author_commit": AUTHOR_COMMIT,
        "architecture": "PVTv2-B2 + EMCAD",
        "runtime_bootstrap": "public pinned EMCAD commit; no Notebook-1 mount",
        "target": "Whole Tumour (WT), binary",
        "input_modalities": [
            "FLAIR",
            "T1-Gd",
            "T2",
        ],
    }

    (
        OUTPUT_ROOT
        / "final_summary.json"
    ).write_text(
        json.dumps(
            final_summary,
            indent=2,
        )
    )

    part5_metadata = {
        "experiment": (
            "EMCAD Experiment 2 - BraTS Domain Generalization"
        ),
        "run": 1,
        "stage": "Part 5 FINAL",
        "epochs_this_stage": [151, 200],
        "epochs_completed_total": [1, 200],
        "total_epochs": TOTAL_EPOCHS,
        "seed": SEED,
        "resumed_from_epoch": 150,
        "best_validation_epoch": best_epoch,
        "best_validation_dice": best_val_dice,
        "test_set_evaluated": True,
        "test_evaluation_count": 1,
        "early_stopping": False,
        "author_commit": AUTHOR_COMMIT,
    }

    (
        OUTPUT_ROOT
        / "part5_metadata.json"
    ).write_text(
        json.dumps(
            part5_metadata,
            indent=2,
        )
    )

    macro = (
        test_summary[
            "macro_patient_metrics"
        ]
    )

    global_metrics = (
        test_summary[
            "global_voxel_metrics"
        ]
    )

    print()
    print("=" * 72)
    print("FINAL RESULTS — BRATS RUN 1")
    print("=" * 72)
    print("Seed:", SEED)
    print("Best epoch:", best_epoch)
    print(
        "Best validation Dice:",
        f"{best_val_dice:.4f}",
    )
    print(
        "Test Dice (patient macro):",
        f"{macro['dice']['mean']:.4f} "
        f"± {macro['dice']['std']:.4f}",
    )
    print(
        "Test IoU (patient macro):",
        f"{macro['iou']['mean']:.4f} "
        f"± {macro['iou']['std']:.4f}",
    )
    print(
        "Test Dice (global voxel):",
        f"{global_metrics['dice']:.4f}",
    )
    print(
        "Test IoU (global voxel):",
        f"{global_metrics['iou']:.4f}",
    )

    if (
        macro["hd95"]["n"] > 0
    ):
        print(
            "Test HD95:",
            f"{macro['hd95']['mean']:.3f} "
            f"± {macro['hd95']['std']:.3f}",
            f"(n={macro['hd95']['n']})",
        )

    print(
        "Empty-prediction patients:",
        test_summary[
            "empty_prediction_patients"
        ],
    )

    print(
        "Final test time:",
        f"{test_elapsed / 60:.1f} minutes",
    )
    print("=" * 72)
    print("BRATS RUN 1 COMPLETE")


if __name__ == "__main__":
    main()
